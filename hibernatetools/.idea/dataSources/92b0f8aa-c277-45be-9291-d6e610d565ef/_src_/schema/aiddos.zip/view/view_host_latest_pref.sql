CREATE VIEW view_host_latest_pref AS
  SELECT
    1 AS `HOST_ID`,
    1 AS `COLTIME`,
    1 AS `CPU_USAGE`,
    1 AS `DISK_USAGE`,
    1 AS `MEM_USAGE`,
    1 AS `MEM_ALLOCATE_USED`,
    1 AS `SWAP_SIZE`,
    1 AS `SWAP_USAGE`,
    1 AS `PROC_NUM`;
