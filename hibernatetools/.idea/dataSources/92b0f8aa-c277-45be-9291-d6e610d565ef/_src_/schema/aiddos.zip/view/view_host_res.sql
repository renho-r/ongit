CREATE VIEW view_host_res AS
  SELECT
    1 AS `ID`,
    1 AS `HOST_ID`,
    1 AS `NAME`,
    1 AS `TYPE`;
