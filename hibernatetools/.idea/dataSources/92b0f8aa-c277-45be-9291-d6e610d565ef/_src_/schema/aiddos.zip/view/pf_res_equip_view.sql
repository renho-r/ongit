CREATE VIEW pf_res_equip_view AS
  SELECT
    1 AS `ID`,
    1 AS `ALIAS`,
    1 AS `EQUIPIP`,
    1 AS `READCOMMUNITY`,
    1 AS `SNMPVER`,
    1 AS `STATUS`;
