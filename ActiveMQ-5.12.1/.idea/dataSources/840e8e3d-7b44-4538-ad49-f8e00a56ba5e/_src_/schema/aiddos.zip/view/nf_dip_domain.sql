CREATE VIEW nf_dip_domain AS
  SELECT
    1 AS `ID`,
    1 AS `IP`,
    1 AS `ALIAS`,
    1 AS `DOMAIN_CODE`;
