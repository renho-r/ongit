CREATE VIEW pf_res_all_view AS
  SELECT
    1 AS `ID`,
    1 AS `ALIAS`,
    1 AS `IP`,
    1 AS `INFO`,
    1 AS `OTHER`,
    1 AS `RESTYPEID`,
    1 AS `STATUS`;
