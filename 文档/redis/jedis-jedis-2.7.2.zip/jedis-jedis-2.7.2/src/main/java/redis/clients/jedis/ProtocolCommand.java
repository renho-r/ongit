package redis.clients.jedis;

public interface ProtocolCommand {

  public byte[] getRaw();

}
