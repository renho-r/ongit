CREATE PACKAGE PKG_ADDCARD IS

  /*
         卡新增
         20140623
  */

  PROCEDURE addcard(v_in_az20  in az20%rowtype,
                    pi_aaz375  in varchar2,
                    pi_aaz400  in varchar2,
                    v_out_az20 out az20%rowtype,
                    msg        out varchar2,
                    flag     out varchar2);

end PKG_ADDCARD;
/
