CREATE package body 注销 is

PROCEDURE zhuXiao(prm_aac998 IN VARCHAR2,
                  prm_aac002 IN VARCHAR2,
                  prm_aac003 IN VARCHAR2,
                  prm_aaz401 IN VARCHAR2,   --省库系统节点ID
                  prm_aaz400 IN VARCHAR2,   --业务系统节点ID
                  prm_aae547 IN VARCHAR2,   --注销原因
                  PRM_AAZ357 IN VARCHAR2,   --发起地业务流水号
                  prm_appcode OUT VARCHAR2,
                  prm_errormsg OUT VARCHAR2)
                  IS
   n_count NUMBER;
   t_aac998 VARCHAR2(20);
   t_ac47 ac47%ROWTYPE;
   BEGIN
     prm_appcode:='ok';
     prm_errormsg:='';
     --存在性验证
     BEGIN
     SELECT aac998 INTO t_aac998 FROM ac47 WHERE aac002=prm_aac002 AND aac003=prm_aac003;
     EXCEPTION
     WHEN no_data_found THEN
       prm_appcode:='err';
       prm_errormsg:='人员不存在'||SQLERRM;
       RETURN;
     END;
     IF t_aac998!=t_aac998 THEN
       prm_appcode:='err';
       prm_errormsg:='人员验证未通过';
       RETURN;
     END IF;
     --查询人员关联信息，进行注销关联或者注销人员信息
     SELECT COUNT(1) INTO n_count FROM az11 WHERE aac998=prm_aac998;
     IF n_count>1 THEN 
       BEGIN
         DELETE az11 WHERE aac998=prm_aac998 
                       AND aaz401=prm_aaz401
                       AND aaz400=prm_aaz400;
       END;
     ELSE 
       BEGIN
         DELETE az11 WHERE aac998=prm_aac998 
                       AND aaz401=prm_aaz401
                       AND aaz400=prm_aaz400;
         --此处应加判断删除行数，如果不是一行，则出错，测试不进行判断
         SELECT * INTO t_ac47 FROM ac47 WHERE aac998=prm_aac998;
         INSERT INTO az19   --已注销人员信息表
          ( aac998,   --部级人员ID
            aac002,   --社会保障号码
            aac058,   --证件类型
            aac147,   --证件号码
            aab099,   --证件有效期限
            aac003,   --姓名
            aac005,   --民族
            aac006,   --出生日期
            aac161,   --国家/地区代码
            aac067,   --手机号码
            aae005,   --固定电话
            aac010,   --户口所在地地址
            aae006,   --常住所在地地址
            aae007,   --常住所在地邮政编码
            aac042,   --监护人姓名
            aac043,   --监护人证件类型
            aac044,   --监护人证件号码
            aca111,   --职业（工种）
            aac204,   --人员持卡状态
            aac060,   --生存状态
            aae138,   --死亡日期
            aae550,   --公安比对标志
            aac209,   --注销日期
            aae547 )  --注销原因
     VALUES 
          ( t_ac47.aac998,   --部级人员ID
            t_ac47.aac002,   --社会保障号码
            t_ac47.aac058,   --证件类型
            t_ac47.aac147,   --证件号码
            t_ac47.aab099,   --证件有效期限
            t_ac47.aac003,   --姓名
            t_ac47.aac005,   --民族
            t_ac47.aac006,   --出生日期
            t_ac47.aac161,   --国家/地区代码
            t_ac47.aac067,   --手机号码
            t_ac47.aae005,   --固定电话
            t_ac47.aac010,   --户口所在地地址
            t_ac47.aae006,   --常住所在地地址
            t_ac47.aae007,   --常住所在地邮政编码
            t_ac47.aac042,   --监护人姓名
            t_ac47.aac043,   --监护人证件类型
            t_ac47.aac044,   --监护人证件号码
            t_ac47.aca111,   --职业（工种）
            t_ac47.aac204,   --人员持卡状态
            t_ac47.aac060,   --生存状态
            t_ac47.aae138,   --死亡日期
            t_ac47.aae550,   --公安比对标志
            SYSDATE,   --注销日期
            prm_aae547); --注销原因
 
         UPDATE az20 SET aaz502='0' WHERE aac998=prm_aac998;
         DELETE ac47 WHERE aac998=prm_aac998;
       END;
     END IF;
     INSERT INTO az30 --插入业务日志表
                    (aaz002,               --业务日志ID
                     aaz375,               --发起地业务流水号
                     aaz400,               --业务发起节点ID
                     aaz007,               --社保卡信息ID
                     aac998,               --部级人员ID
                     aaa235,               --业务类型编码
                     aae036,               --业务处理日期
                     aad127,               --附件张数
                     aaf018,               --省行政区划
                     aaf017,               --市行政区划
                     aae013,               --备注
                     aae512)               --本地处理结果
                  VALUES
                    (SEQ_AAZ002.NEXTVAL,    
                     PRM_aaz357,  
                     PRM_aaz400,   
                     NULL,                  
                     prm_aac998,        
                     '003',                
                     SYSDATE,               
                     '1',                   
                     PRM_aaz401,        
                     NULL,                  
                     NULL,                  
                     '1');    
   END zhuXiao;
end 注销;
/
