CREATE package body PKG_A_CRITICALINFOCHANGE is

  /*--------------------------------------------------------------------------
  || 过程名称 ：PKG_A_CRITICALINFOCHANGE
  || 功能描述 ：
  ||            
  ||
  || 作    者 ：sunab  完成日期 ：20140624
  ||--------------------------------------------------------------------------
  || 修改记录 ：
  ||-------------------------------------------------------------------------*/
   PROCEDURE PKG_A_CRITICALINFOCHANGE(PRM_AAC998 IN NUMBER,--部级人员ID
                                      PRM_AAC002 IN VARCHAR2,--社会保障号码
                                      PRM_AAC997 IN VARCHAR2,--人员信息版本号
                                      PRM_AAZ400 IN VARCHAR2,--业务发起节点
                                      PRM_AAE122 IN VARCHAR2,--变更信息项
                                      PRM_AAE123 IN VARCHAR2,--变更前信息
                                      PRM_AAE124 IN VARCHAR2,--变更后信息
                                      PRM_APPCODE  OUT NUMBER,
                                      PRM_ERRMSG   OUT VARCHAR2) IS
     
  COUNT_AZ15 NUMBER(4);
  COUNT_AZ10 NUMBER(4);
  COUNT_AZ11 NUMBER(4);
  N_AAC997   VARCHAR2(12);
  N_AAC998   NUMBER(20);
  N_AAC002   VARCHAR2(18);
  N_AAC003   VARCHAR2(30);
  --N_AAC067   VARCHAR2(11);
  V_AAC997   VARCHAR2(12);
  V_AAZ002   NUMBER(16);
  V_AAZ375   VARCHAR2(18);
  V_AAZ205   NUMBER(16);
  V_AAE155   VARCHAR2(100);
  
  BEGIN
    PRM_APPCODE := -1;
    PRM_ERRMSG  := '';
      
    --部级人员ID不能为空          
    IF PRM_AAC998 IS NULL THEN
      PRM_ERRMSG  := '部级人员ID不能为空，请检查!';
      RETURN;
    END IF;
    --人员信息版本号不能为空
    IF PRM_AAC997 IS NULL THEN
      PRM_ERRMSG  := '人员信息版本号不能为空，请检查!';
      RETURN;
    END IF;
    
    --变更信息项校验（只能是姓名和社会保障号码）
    IF PRM_AAE122 <> 'AAC003' AND PRM_AAE122 <> 'AAC002' THEN
      PRM_ERRMSG  := '变更信息项不正确，请检查!';
      RETURN;
    END IF;
    
    IF PRM_AAE122 = 'AAC002' THEN
      BEGIN
        SELECT COUNT(1)
          INTO COUNT_AZ10
          FROM AZ10 
         WHERE AAC002 = PRM_AAE124;
      END;
    END IF;
    
    --判断该人员是否处于锁定期
    BEGIN
      SELECT COUNT(1)
        INTO COUNT_AZ15
        FROM AZ15 
       WHERE AAC002 = PRM_AAC002;
    END;
    IF COUNT_AZ15 > 0 then
       PRM_ERRMSG := '变更人员处于社会保障号锁定期，不可进行信息修改操作！';
       RETURN;
    END IF;
    
    --查询部级人员ID,人员信息版本号 
    BEGIN  
      SELECT AAC998,AAC997,AAC002,AAC003 
        INTO N_AAC998,N_AAC997,N_AAC002,N_AAC003
        FROM AZ10 
       WHERE AAC998 = PRM_AAC998;
    EXCEPTION
      --人员存在性校验
      WHEN NO_DATA_FOUND THEN
        PRM_ERRMSG := '没有该人员信息，不能发起此关键信息变更业务！';
        RETURN;
    END;
    
    --人员一致性校验
    IF N_AAC997 <> PRM_AAC997 THEN
       PRM_ERRMSG := '人员信息版本号不一致，需要与部库人员信息版本号一致，调用人员统一验证！';
       RETURN;
    END IF;
    IF PRM_AAE122 = 'AAC003' THEN
      IF N_AAC003 <> PRM_AAE123 THEN
         PRM_ERRMSG := '变更前信息与库内对应信息不一致，请检查！';
         RETURN;
      END IF;
      /*IF N_AAC003 = PRM_AAE124 THEN
         --号同，名同，则部库返回给业务系统变更项已存在的错误（由业务系统断开关联，本地变更关键信息项，本地新增人员信息关联。可调用公共函数。）

      END IF;*/
    END IF;
    IF PRM_AAE122 = 'AAC002' THEN
      IF N_AAC002 <> PRM_AAE123 THEN
         PRM_ERRMSG := '变更前信息与库内对应信息不一致，请检查！';
         RETURN;
      END IF;
      /*IF N_AAC002 = PRM_AAE124 THEN
         --号同，名同，则部库返回给业务系统变更项已存在的错误（由业务系统断开关联，本地变更关键信息项，本地新增人员信息关联。可调用公共函数。）
         
      END IF;*/
    END IF;
    
    /*IF COUNT_AZ10 > 0 then
       --进入勘误流程
         
    END IF;*/
    
    --查询人员多级关联信息
    BEGIN
      SELECT COUNT(1)
        INTO COUNT_AZ11
        FROM AZ11 
       WHERE AAC998 = PRM_AAC998;
    END;
    /*IF COUNT_AZ11 > 1 THEN
      --判断手机号是否为空（手机号为空不允许会商）
      BEGIN
        SELECT AAC067 
          INTO N_AAC067 
          FROM AC47 
         WHERE AAC998 = PRM_AAC998 ;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          PRM_ERRMSG := '该人员人员手机号为空，不允许进行会商操作！';
          RETURN;
      END;
      
      --进入会商流程
         
      END IF;
    END IF;*/
    
    --变更人员基础信息表和人员识别信息表
    SELECT TO_CHAR(SYSDATE,'yyMMddHH24MISS') INTO V_AAC997 FROM DUAL;  
    IF PRM_AAE122 = 'AAC003' THEN
      UPDATE AC47
         SET AAC003 = PRM_AAE124
       WHERE AAC998 = PRM_AAC998;
      UPDATE AZ10
         SET AAC003 = PRM_AAE124,
             AAC997 = V_AAC997
       WHERE AAC998 = PRM_AAC998;
    END IF;
    IF PRM_AAE122 = 'AAC002' THEN
      UPDATE AC47
         SET AAC002 = PRM_AAE124
       WHERE AAC998 = PRM_AAC998;
      UPDATE AZ10
         SET AAC002 = PRM_AAE124,
             AAC997 = V_AAC997
       WHERE AAC998 = PRM_AAC998;
    END IF;
    
    BEGIN
      --插入业务日志表
      SELECT SEQ_AAZ002.NEXTVAL INTO V_AAZ002 FROM DUAL;
      SELECT SEQ_AAZ375.NEXTVAL INTO V_AAZ375 FROM DUAL;
      INSERT INTO AZ30
        (AAZ002, AAZ375, AAZ400, AAZ007, AAC998, AAA235, 
         AAE036, AAD127, AAF018, AAF017, AAE013, AAE512)
      VALUES
        (V_AAZ002,
         V_AAZ375,
         PRM_AAZ400,
         '',
         PRM_AAC998,
         '002',
         SYSDATE,
         '',
         '',
         '',
         '部级人员关键信息变更',
         '1'
        );
      
      --插入人员基础信息变更明细表
      SELECT SEQ_AAZ205.NEXTVAL INTO V_AAZ205 FROM DUAL;
      IF PRM_AAE122 = 'AAC003' THEN
        V_AAE155 := '姓名' ;
      END IF;
      IF PRM_AAE122 = 'AAC002' THEN
        V_AAE155 := '社会保障号码' ;
      END IF;
      INSERT INTO AZ12
        (AAZ205, AAZ002, AAC998, AAE122, 
         AAE155, AAE123, AAE124, AAE035)
      VALUES
        (V_AAZ205,
         V_AAZ002,
         PRM_AAC998,
         PRM_AAE122,
         V_AAE155,
         PRM_AAE123,
         PRM_AAE124,
         SYSDATE
        );
      
      --Insert into 人员信息变更推送队列表 values (…);
      
    END;
    
    PRM_APPCODE := 0;
    PRM_ERRMSG  := '部级人员关键信息变更成功！';
            
  END PKG_A_CRITICALINFOCHANGE;
  
END PKG_A_CRITICALINFOCHANGE;
/
