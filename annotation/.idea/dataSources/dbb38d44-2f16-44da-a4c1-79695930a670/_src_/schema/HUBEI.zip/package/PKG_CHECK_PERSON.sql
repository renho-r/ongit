CREATE PACKAGE PKG_Check_Person IS

  PROCEDURE ifExists(v_aac002 IN VARCHAR2,
                     v_aac003 IN VARCHAR2,
                     RETCODE  OUT NUMBER,
                     RETMSG   OUT VARCHAR2);
  PROCEDURE ifAlone(v_aac002 IN VARCHAR2,
                    v_aac003 IN VARCHAR2,
                    RETCODE  OUT NUMBER,
                    RETMSG   OUT VARCHAR2);

  PROCEDURE ifLegal(RETCODE OUT NUMBER, RETMSG OUT VARCHAR2); --用一个只有两个数据项的表check_support来模拟Map

  PROCEDURE ifEqual(v_ac47   IN ac47%rowtype,
                    v_type   IN VARCHAR2,
                    n_aac997 in NUMBER,
                    RETCODE  OUT NUMBER,
                    RETMSG   OUT VARCHAR2);

END PKG_Check_Person;
/
