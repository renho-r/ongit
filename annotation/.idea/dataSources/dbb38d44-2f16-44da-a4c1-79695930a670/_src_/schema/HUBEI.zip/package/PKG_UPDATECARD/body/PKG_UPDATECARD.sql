CREATE PACKAGE BODY PKG_UPDATECARD IS

  /*
         省持卡库
         卡变更
         20140624 
  */

  PROCEDURE updatecard(v_az21     in az21%rowtype, --变更明细对象
                       pi_aaz375  in varchar2,     --发起地业务流水号
                       pi_aaz400  in varchar2,     --业务发起节点ID
                       v_out_az21 out az21%rowtype,
                       v_out_az20 out az20%rowtype,
                       msg        out varchar2,
                       flag       out varchar2) IS
    v_aaz007 az20.aaz007%type; --社保卡信息id 
    v_aaz502 az20.aaz502%type; --卡应用状态 
    v_az21_1 az21%rowtype;
    errmsg   varchar2(100); --说明
    s_flag   varchar2(1) := 0; --业务标志
  BEGIN
    v_az21_1 := v_az21;
  
    begin
      select * into v_out_az20 from az20 where aaz007 = v_az21.aaz007;
    exception
      when no_data_found then
        errmsg := '查找不到对应卡信息，不能办理卡变更业务';
    end;
  
    if errmsg is null then
      --卡状态 aaz502：0封存，1正常，2挂失，3应用锁定，4临时挂失，9注销
      if v_out_az20.aaz502 = '9' then
        errmsg := '此卡已注销';
      elsif v_out_az20.aaz502 = '0' then
        --封存：已发卡未激活
        errmsg := '此卡已封存,不允许操作';
      elsif v_out_az20.aaz502 = '3' then
        errmsg := '此卡已锁定，不允许操作';
      end if;
      --只有在卡状态为‘正常’情况下可以将卡状态变更为封存、挂失、临时挂失、应用锁定这些状态
      --封存状态是可以挂失，注销
      if v_az21.aae124 = '2' then
        --挂失操作
        if v_out_az20.aaz502 = '1' then
          --状态 1 正常
          update az20
             set aaz502 = v_az21.aae124
           where aaz007 = v_az21.aaz007
             and aaz502 = '1';
          s_flag := 1;
        else
          errmsg := '此卡已挂失，不允许重复挂失';
        end if;
      end if;
      --如果是解挂操作，则判断此时卡状态应为挂失、临时挂失状态才可做
      if v_az21.aae124 = '1' then
        --解挂操作      
        if v_out_az20.aaz502 = '2' then
          --状态 2 挂失
          update az20
             set aaz502 = v_az21.aae124
           where aaz007 = v_az21.aaz007
             and aaz502 = '2';
          s_flag := 1;
        else
          errmsg := '此卡已处正常状态，不允许解挂操作';
        end if;
      end if;
      --注销业务
      if v_out_az20.aaz502 = '9' then
        --注销操作      
        if v_out_az20.aaz502 <> '9' then
          update az20
             set aaz502 = v_az21.aae124
           where aaz007 = v_az21.aaz007
             and aaz502 <> '9';
          s_flag := 1;
        else
          errmsg := '此卡已注销！';
        end if;
      end if;
    
      --没有异常，则插入明细表和业务日志
      if s_flag = 1 then
        --变更日期
        v_az21_1.aae035 := sysdate;
        v_az21_1.aae123 := v_out_az20.aaz502;
        --插入变更社保卡变更明细表ID
        select seq_aaz205.nextval into v_az21_1.aaz205 from dual;
        --业务日志ID
        select seq_aaz002.nextval into v_az21_1.aaz002 from dual;
        --插入变更表
        insert into az21 values v_az21_1;
        msg := '社会保障卡号：' || v_az21_1.aaz007 || ',日期：' ||
               to_char(v_az21_1.aae035, 'yyyymmdd') || '办理卡状态变更业务';
      end if;
      --业务日志表
      INSERT INTO az30
        (aaz002, --业务日志ID
         aaz375, --发起地业务流水号
         aaz400, --业务发起节点ID
         aaz007, --社保卡信息ID
         aac998, --部级人员ID
         aaa235, --业务类型编码
         aae036, --业务处理日期
         aad127, --附件张数
         aaf018, --省行政区划
         aaf017, --市行政区划
         aae013, --备注
         aae512) --本地处理结果
      VALUES
        ('11111', --业务日志ID
         pi_aaz375, --发起地业务流水号
         pi_aaz400, --业务发起节点ID
         '1111', --社保卡信息ID
         null, --部级人员ID
         '005', --业务类型编码
         SYSDATE, --业务处理日期
         '0', --附件张数
         v_out_az20.aab301, --省行政区划
         NULL, --市行政区划
         msg, --备注
         s_flag); --本地处理结果
    end if;
    msg := msg || errmsg;
  
    v_out_az21 := v_az21_1;
    flag       := s_flag;
  exception
    when others then
      raise_application_error(-20001, SQLERRM);
  END updatecard;

  /*
    卡变更测试
  */
  PROCEDURE test_updatecard(pi_aaz007 in number, msg out varchar2) IS
    v_in_az21  az21%rowtype;
    errmsg     varchar2(100);
    pi_aaz375  az30.aaz375%type; --发起地业务流水号 
    pi_aaz400  az30.aaz400%type; --业务发起节点id 
    v_aae514   az22.aae514%type; --请求报文
    v_out_az21 az21%rowtype;
    v_out_az20 az20%rowtype;
    v_date     date;
    s_msg      varchar2(100); --省返回信息
    b_msg      varchar2(100); --部返回信息
    s_flag     varchar2(1); --省标志
    b_flag     varchar2(1); --部标志
  BEGIN
    v_in_az21.aaz007 := pi_aaz007;
    v_in_az21.aae122 := 'AAZ502';
    v_in_az21.aae155 := '卡应用状态 ';
    v_in_az21.aae123 := '1';
    v_in_az21.aae124 := '2';
    pi_aaz375        := '14069900001';
    pi_aaz400        := '192.168.1';
    v_date           := sysdate;
    --多条
    --for
    --省库变更
    updatecard(v_in_az21, --变更明细入参
               pi_aaz375,
               pi_aaz400,
               v_out_az21, --变更明细表出参
               v_out_az20, --卡基础信息出参
               s_msg,
               s_flag);
    --end loop;
    --批量打包组装或者直接用业务上传报文
    msg := msg || '省：' || s_msg || chr(13);
    --省库返回成功，部库变更
    if s_flag = 1 then
      bjckk.pkg_updatecard.updatecard(v_out_az21, --部变更明细入参
                                      pi_aaz375,
                                      pi_aaz400,
                                      b_msg,
                                      b_flag);
      --end loop;
      msg := msg || '部：' || b_msg;
      --部库业务处理异常，插入重发队列
      if b_flag = 0 then
        --v_aae514 := '社保卡信息ID|社会保障卡卡号|卡识别码|部级人员ID|发卡地行政区划代码|变更前状态|变更后状态';
        v_aae514 := '<HEAD>' || chr(13);
        v_aae514 := v_aae514 || '|' || '1.0' || '|' || '100001' || '|' ||
                    '1.1.1' || '1.1.1' || '|' || pi_aaz400 || '|' ||
                    pi_aaz375 || '|' || '005' || '|' || '1' || '|' ||
                    to_char(sysdate, 'yyyymmdd') || '|' ||
                    to_char(sysdate, 'yyyymmdd') || '|' ||
                    to_char(sysdate, 'yyyymmdd') || '|' || '附件标志' || '|' || 'CA' || '|' ||
                    '经办人' || '|' || '设备证书';
        v_aae514 := v_aae514 || chr(13) || '<CARDMODIFY>' || chr(13) ||
                    v_out_az20.aaz007 || '|' || v_out_az20.aaz500 || '|' ||
                    v_out_az20.aaz501 || '|' || v_out_az20.aac998 || '|' ||
                    v_out_az20.aab301 || '|' || v_out_az21.aae123 || '|' ||
                    v_out_az21.aae124 || chr(13);
        v_aae514 := v_aae514 || '<END>';
        insert into az22
          (aaz365, aae514, aaa235, aae532, aaz007)
        values
          (seq_aaz365.nextval, v_aae514, '004', sysdate, pi_aaz007);
      end if;
    end if;
    msg := msg || errmsg;
  END test_updatecard;

  /*
    卡新增测试
  */
  PROCEDURE test_addcard(bjbh in varchar2,
                         sbkh in varchar2,
                         msg  out varchar2) IS
    v_az20     az20%rowtype;
    v_out_az20 az20%rowtype;
    pi_aaz375  az30.aaz375%type; --发起地业务流水号 
    pi_aaz400  az30.aaz400%type; --业务发起节点id 
    v_aae514   az22.aae514%type; --请求报文
    s_msg      varchar2(100); --省返回信息
    b_msg      varchar2(100); --部返回信息
    s_flag     varchar2(1); --省标志
    b_flag     varchar2(1); --部标志
  BEGIN
    v_az20.aac998 := bjbh; --部级人员ID
    v_az20.aaz500 := sbkh; --社会保障卡卡号  
    v_az20.aaz501 := 100009889; --卡识别码        
    v_az20.aaz507 := ''; --卡片复位信息    
    v_az20.aaz503 := 20140624; --发卡日期        
    v_az20.aab099 := 20240624; --证件有效期限    
    v_az20.aaz502 := '1'; --卡应用状态      
    v_az20.aac080 := ''; --开户银行行号    
    v_az20.aac203 := ''; --银行卡卡号      
    v_az20.aab301 := '140699'; --发卡行政区划    
    v_az20.aac003 := '李4'; --卡面姓名        
    v_az20.aac002 := sbkh; --卡面社会保障号码
    pi_aaz375     := '14069900001';
    pi_aaz400     := '192.168.1';
    --省库新增
    pkg_addcard.addcard(v_az20,
                        pi_aaz375,
                        pi_aaz400,
                        v_out_az20,
                        s_msg,
                        s_flag);
    msg := msg || '省：' || s_msg || chr(13);
    --部库新增
    if s_flag = 1 then
      bjckk.pkg_addcard.addcard(v_out_az20,
                                pi_aaz375,
                                pi_aaz400,
                                b_msg,
                                b_flag);
      msg := msg || '部：' || b_msg;
      --部库业务处理异常，插入重发队列
      if b_flag = 0 then
        --v_aae514 := '社会保障卡卡号|卡识别码|发卡地行政区划代码|卡片复位信息|发卡日期|证件有效期限|卡应用状态|开户银行行号|部级人员ID|卡面姓名|卡面社会保障号码';
        v_aae514 := '<HEAD>' || chr(13);
        v_aae514 := v_aae514 || '|' || '1.0' || '|' || '100001' || '|' ||
                    '1.1.1' || '1.1.1' || '|' || pi_aaz400 || '|' ||
                    pi_aaz375 || '|' || '005' || '|' || '1' || '|' ||
                    to_char(sysdate, 'yyyymmdd') || '|' ||
                    to_char(sysdate, 'yyyymmdd') || '|' ||
                    to_char(sysdate, 'yyyymmdd') || '|' || '附件标志' || '|' || 'CA' || '|' ||
                    '经办人' || '|' || '设备证书';
        v_aae514 := v_aae514 || chr(13) || '<CARDADD>' || chr(13) ||
                    v_out_az20.aaz500 || '|' || v_out_az20.aaz501 || '|' ||
                    v_out_az20.aab301 || '|' || v_out_az20.aaz507 || '|' ||
                    v_out_az20.aaz503 || '|' || v_out_az20.aab099 || '|' ||
                    v_out_az20.aaz502 || '|' || v_out_az20.aac998 || '|' ||
                    v_out_az20.aac003 || '|' || v_out_az20.aac002 ||
                    chr(13);
        v_aae514 := v_aae514 || '<END>';
        insert into az22
          (aaz365, aae514, aaa235, aae532, aaz007)
        values
          (seq_aaz365.nextval, v_aae514, '004', sysdate, v_out_az20.aaz007);
      end if;
    end if;
  
  exception
    when others then
      raise_application_error(-20001, SQLERRM);
  END test_addcard;
END PKG_UPDATECARD;
/
