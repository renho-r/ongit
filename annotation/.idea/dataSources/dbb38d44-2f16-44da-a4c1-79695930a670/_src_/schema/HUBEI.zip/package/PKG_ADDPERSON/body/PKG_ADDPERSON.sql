CREATE PACKAGE body pkg_addPerson IS
  v_count number;

  PROCEDURE addPersonForProvince(v_ac47   IN ac47%rowtype,
                                 v_AAZ401 in VARCHAR2,
                                 v_AAZ400 in VARCHAR2,
                                 RETCODE  OUT NUMBER,
                                 RETMSG   OUT VARCHAR2) is
  begin
  
    select count(1)
      into v_count
      from ac47 a
     where a.aac998 = v_ac47.aac998;
  
    if v_count = 0 then
      insert into ac47 values v_ac47;
    end if;
  
    insert into az11
      (AAC998, -- NUMBER(20)                   部级人员ID 
       AAZ401, -- VARCHAR2(9) Y                省库系统节点ID 
       AAZ400, -- VARCHAR2(9)                  业务系统节点ID 
       AAE548)
      select v_ac47.aac998 AAC998, -- NUMBER(20)                   部级人员ID 
             v_AAZ401      AAZ401, -- VARCHAR2(9) Y                省库系统节点ID 
             v_AAZ400      AAZ400, -- VARCHAR2(9)                  业务系统节点ID 
             sysdate       AAE548
        from dual
       where not exists (select 1
                from az11 a
               where a.aac998 = v_ac47.aac998
                 and AAZ400 = v_AAZ400);
  
  EXCEPTION
    WHEN OTHERS THEN
      RETCODE := -1;
      RETMSG  := sqlerrm || '人员新增错误！';
  end addPersonForProvince;

  PROCEDURE addPersonInterfaceForProvince(v_ac47   IN ac47%rowtype,
                                          v_AAZ401 in VARCHAR2,
                                          v_AAZ400 in VARCHAR2,
                                          v_AAZ372 in number,
                                          RETCODE  OUT NUMBER,
                                          RETMSG   OUT VARCHAR2) is
  
  begin
    addPersonForProvince(v_ac47, v_AAZ401, v_AAZ400, RETCODE, RETMSG);
  
    insert into az51
      (AAZ369, -- NUMBER(16)                      轮询公告ID 
       AAZ002, -- NUMBER(16)                      业务日志ID 
       AAZ372, -- NUMBER(16)                      推送队列ID 
       AAE546, -- VARCHAR2(1)                     轮询类型   
       AAZ400, -- VARCHAR2(9)                     系统节点ID 
       AAC998, -- NUMBER(20)                      部级人员ID 
       AAC002, -- VARCHAR2(18)   Y                社会保障号码 
       AAC003, -- VARCHAR2(50)   Y                发起方姓名 
       AAZ367, -- NUMBER(16)                      会商勘误流水号 
       AAE516, -- DATE           Y                会商勘误发起日期 
       AAZ500, -- VARCHAR2(9)    Y                会商勘误发起系统节点 
       ASR031, -- VARCHAR2(1)    Y                公告阅读标志 
       ASR032, -- DATE           Y                公告阅读日期 
       APF259, -- VARCHAR2(1)    Y                反馈结果   
       APF255, -- DATE           Y                反馈日期   
       AAE541, -- VARCHAR2(3)    Y                会商勘误结果 
       AAE529, -- VARCHAR2(500)  Y                信息摘要   
       AAE522, -- VARCHAR2(1000) Y                修改内容结构串 
       AAE505, -- NUMBER(16)     Y                轮询批次号 
       AAA235, -- VARCHAR2(3)    Y                业务类型编码 
       AAE556 -- DATE           Y                轮询日期  
       )
      select seq_aaz369.nextval AAZ369, -- NUMBER(16)                      轮询公告ID 
             seq_aaz002.nextval AAZ002, -- NUMBER(16)                      业务日志ID 
             v_AAZ372 AAZ372, -- NUMBER(16)                      推送队列ID 
             '1' AAE546, -- VARCHAR2(1)                     轮询类型   
             v_AAZ400 AAZ400, -- VARCHAR2(9)                     系统节点ID 
             v_ac47.aac998 AAC998, -- NUMBER(20)                      部级人员ID 
             v_ac47.aac002 AAC002, -- VARCHAR2(18)   Y                社会保障号码 
             v_ac47.aac003 AAC003, -- VARCHAR2(50)   Y                发起方姓名 
             '' AAZ367, -- NUMBER(16)                      会商勘误流水号 
             '' AAE516, -- DATE           Y                会商勘误发起日期 
             '' AAZ500, -- VARCHAR2(9)    Y                会商勘误发起系统节点 
             0 ASR031, -- VARCHAR2(1)    Y                公告阅读标志 
             null ASR032, -- DATE           Y                公告阅读日期 
             0 APF259, -- VARCHAR2(1)    Y                反馈结果   
             null APF255, -- DATE           Y                反馈日期   
             null AAE541, -- VARCHAR2(3)    Y                会商勘误结果 
             null AAE529, -- VARCHAR2(500)  Y                信息摘要   
             null AAE522, -- VARCHAR2(1000) Y                修改内容结构串 
             null AAE505, -- NUMBER(16)     Y                轮询批次号 
             '001' AAA235, -- VARCHAR2(3)    Y                业务类型编码 
             sysdate AAE556 -- DATE           Y                轮询日期  
        from dual;
  EXCEPTION
    WHEN OTHERS THEN
      RETCODE := -1;
      RETMSG  := sqlerrm || '人员新增错误！';
  end addPersonInterfaceForProvince;

end pkg_addPerson;
/
