CREATE PACKAGE BODY PKG_ADDCARD IS

  /*
         省持卡库
         卡新增
         20140625
         fht
  */
  PROCEDURE ADDCARD(v_in_az20  in az20%rowtype, --卡信息对象
                    pi_aaz375  in varchar2,     --发起地业务流水号
                    pi_aaz400  in varchar2,     --业务发起节点ID
                    v_out_az20 out az20%rowtype,
                    msg        out varchar2,
                    flag       out varchar2) IS
    cardID   varchar2(47); --社保卡ID
    v_az20   az20%ROWTYPE; --社保卡基本信息
    e_aaz503 az20.aaz503%type := '20150601'; --截止日期
    n_count  number;
    n_count0 number;
    n_count1 number;
    n_count2 number;
    errmsg   varchar2(1000);
  BEGIN
    v_az20 := v_in_az20;
    flag   := 0;
    select seq_aaz007.nextval into v_az20.aaz007 from dual;
    --检查该人员是否在人员信息库中
    select count(1)
      into n_count0
      from ac47
     where aac998 = v_in_az20.aac998
       and aac002 = v_in_az20.aac002
       and aac003 = v_in_az20.aac003;
    if n_count0 > 0 then
      --检查该人员是否允许发卡，对人员进行卡新增插入
      select count(1)
        into n_count
        from az20
       where aac998 = v_in_az20.aac998
         and aac002 = v_in_az20.aac002
         and aac003 = v_in_az20.aac003;
      if n_count = 0 then
        insert into az20 values v_az20;
        flag := 1;
        msg  := '社会保障卡号：' || v_in_az20.aaz500 || '日期：' || v_in_az20.aaz503 ||
                ',办理卡新增';
      else
        if e_aaz503 >= v_in_az20.aaz503 then
          --过渡期,同一个人可以多张卡
          select count(1)
            into n_count1
            from az20
           where aaz500 = v_in_az20.aaz500
             and aab301 = v_in_az20.aab301;
          if n_count1 = 0 then
            insert into az20 values v_az20;
            flag := 1;
            msg  := '社会保障卡号：' || v_in_az20.aaz500 || '日期：' ||
                    v_in_az20.aaz503 || ',办理卡新增';
          else
            flag := 0;
            msg  := '社会保障卡号：' || v_in_az20.aaz500 || ',存在此卡，不允许办理卡新增业务！';
          end if;
        else
          --非过渡期，同一个省份同一个人不能多次发卡
          select count(1)
            into n_count2
            from az20
           where aac998 = v_in_az20.aac998
             and aab301 = v_in_az20.aab301
             and aaz502 <> '9';
          if n_count2 = 0 then
            insert into az20 values v_az20;
            flag := 1;
            msg  := '社会保障卡号：' || v_in_az20.aaz500 || '日期：' ||
                    v_in_az20.aaz503 || ',办理卡新增';
          else
            flag := 0;
            msg  := '社会保障卡号：' || v_in_az20.aaz500 || ',存在此卡，不允许办理卡新增业务！';
          end if;
        end if;
      end if;
      --业务日志表
      INSERT INTO az30
        (aaz002, --业务日志ID
         aaz375, --发起地业务流水号
         aaz400, --业务发起节点ID
         aaz007, --社保卡信息ID
         aac998, --部级人员ID
         aaa235, --业务类型编码
         aae036, --业务处理日期
         aad127, --附件张数
         aaf018, --省行政区划
         aaf017, --市行政区划
         aae013, --备注
         aae511， --交易异常需对账 
         aae518， --部库处理结果 
         aae512 --本地处理结果
         )
      VALUES
        (seq_aaz002.nextval, --业务日志ID
         pi_aaz375, --发起地业务流水号
         pi_aaz400, --业务发起节点ID
         v_az20.aaz007, --社保卡信息ID
         v_in_az20.aac998, --部级人员ID
         '004', --业务类型编码
         SYSDATE, --业务处理日期
         '0', --附件张数
         v_in_az20.aab301, --省行政区划
         NULL, --市行政区划
         msg, --备注
         '0' ， --交易异常需对账 
         '0' ， --部库处理结果
         flag); --本地处理结果
    else
      flag := 0;
      msg  := '没有编号为' || v_in_az20.aac998 || '这个人，不允许办理卡新增业务！';
    end if;
    --if flag = 1 then
    --将成功结果返回，以此结果集做为部库新增条件
    v_out_az20 := v_az20;
    --end if;
  exception
    when others then
      flag := 0;
      raise_application_error(-20001, SQLERRM);
  END ADDCARD;

END PKG_ADDCARD;
/
