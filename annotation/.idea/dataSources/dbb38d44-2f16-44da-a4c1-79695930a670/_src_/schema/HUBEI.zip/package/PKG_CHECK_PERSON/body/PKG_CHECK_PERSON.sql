CREATE PACKAGE BODY PKG_Check_Person AS

  V_COUNT  NUMBER(4);
  v_rate   number := 10;
  n_police number := 0;

 
  PROCEDURE ifExists(v_aac002 IN VARCHAR2,
                     v_aac003 IN VARCHAR2,
                     RETCODE  OUT NUMBER,
                     RETMSG   OUT VARCHAR2) IS
  
  BEGIN
  
    RETCODE := 0;
  
    select decode(count(1), 0, 0, 1)
      into V_COUNT
      from az10 a
     where a.aac002 = v_aac002
       and a.aac003 = v_aac003;
  
    if V_COUNT > 0 then
      RETCODE := V_COUNT;
    end if;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETCODE := -1;
      RETMSG  := sqlerrm || '人员存在性验证错误！';
  END ifExists;

  PROCEDURE ifAlone(v_aac002 IN VARCHAR2,
                    v_aac003 IN VARCHAR2,
                    RETCODE  OUT NUMBER,
                    RETMSG   OUT VARCHAR2) IS
  
  BEGIN
  
    RETCODE := 0;
  
    select decode(count(1), 0, 0, 1)
      into V_COUNT
      from az10 a
     where a.aac002 = v_aac002
       and a.aac003 = v_aac003;
  
    if V_COUNT > 0 then
      RETCODE := V_COUNT;
    end if;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETCODE := -1;
      RETMSG  := sqlerrm || '人员唯一性验证错误！';
  END ifAlone;

  PROCEDURE ifLegal(RETCODE OUT NUMBER, RETMSG OUT VARCHAR2) IS
    --用一个只有两个数据项的表check_support来模拟Map
  
    cursor check_person is
      select * from check_support;
    v_length number;
    v_type   number;
    v_aac058 varchar2(2);
    v_aac147 varchar2(20);
    v_aac002 varchar2(20);
    v_result varchar2(20);
  BEGIN
  
    RETCODE := 0;
    RETMSG  := '';
    --模拟从Map里面取各个数据项的数据,如果证件类型是身份证的话，需要校验身份证的位数和编码
    select a.columnvalue
      into v_aac058
      from check_support a
     where a.columnname = 'AAC058';
    select a.columnvalue
      into v_aac147
      from check_support a
     where a.columnname = 'AAC147';
     select a.columnvalue
      into v_aac147
      from check_support a
     where a.columnname = 'AAC002';
  
    if v_aac058 = '01' then
      if length(v_aac147) != 18 or length(v_aac002) != 18 then
        RETMSG  := RETMSG || '人员身份证号' || v_aac147 || '不为18位';
        RETCODE := 1;
      end if;
      CHECK_IDCARD_VALIDATE(V_AAC147, v_result);
      if v_result != V_AAC147 or v_result != V_AAC002 then
        RETMSG  := RETMSG || '人员身份证号' || v_aac147 || '编码错误';
        RETCODE := 1;
      end if;
    end if;
  
  --判断每一个数据项的数据类型和长度是否符合数据库的定义
    for i_check_person in check_person loop
    
      select a.DATA_TYPE, a.DATA_LENGTH
        into v_type, v_length
        from user_tab_columns a
       where a.TABLE_NAME = 'AC47'
         and a.COLUMN_NAME = i_check_person.columnname;
    
      if length(i_check_person.columnvalue) > v_length then
        RETMSG  := RETMSG || '人员信息' || i_check_person.columnname || '长度过长';
        RETCODE := 1;
      end if;
    
      if v_type = 'NUMBER' then
        select nvl(translate(i_check_person.columnvalue, '0123456789', ''),
                   0)
          into V_COUNT
          from dual;
      
        if V_COUNT != 0 then
          RETMSG  := RETMSG || '人员信息' || i_check_person.columnname ||
                     '不为数字';
          RETCODE := 1;
        end if;
      end if;
    
    end loop;
  
    /*    if n_police='1' then
      
    end if;*/
  
  EXCEPTION
    WHEN OTHERS THEN
      RETCODE := -1;
      RETMSG  := sqlerrm || '人员唯一性验证错误！';
  END ifLegal;

  PROCEDURE ifEqual(v_ac47   IN ac47%rowtype,
                    v_type   IN VARCHAR2,
                    n_aac997 in NUMBER,
                    RETCODE  OUT NUMBER,
                    RETMSG   OUT VARCHAR2) IS
    i_ac47   ac47%rowtype;
    v_aac997 number;
    v_aac998 number;
    i_rate   number;
  BEGIN
  
    RETCODE := 0;
    RETMSG  := null;
  
    if nvl(v_ac47.aac998, 0) != 0 then
      begin
        select a.aac998, a.aac997
          into v_aac998, v_aac997
          from az10 a
         where a.aac998 = v_ac47.aac998;
      exception
        when no_data_found then
          RETCODE := -1;
          RETMSG  := '无对应人员信息！';
      end;
    else
      begin
        select a.aac998, a.aac997
          into v_aac998, v_aac997
          from az10 a
         where a.aac002 = v_ac47.aac002
           and a.aac003 = v_ac47.aac003;
      exception
        when no_data_found then
          RETCODE := -1;
          RETMSG  := '无对应人员信息！';
      end;
    end if;
    i_rate := dbms_random.value(1, 10);
    if (v_aac997 = n_aac997 and i_rate > v_rate) or (v_aac997 != n_aac997) then
      select * into i_ac47 from ac47 a where a.aac998 = v_aac998;
    
      if v_type = '1' then
        --全校验
        if i_ac47.aac998 = v_ac47.aac998 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac002 = v_ac47.aac002 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac058 = v_ac47.aac058 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac147 = v_ac47.aac147 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aab099 = v_ac47.aab099 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac003 = v_ac47.aac003 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac004 = v_ac47.aac004 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac005 = v_ac47.aac005 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac006 = v_ac47.aac006 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac161 = v_ac47.aac161 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac067 = v_ac47.aac067 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aae005 = v_ac47.aae005 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aae005 = v_ac47.aae005 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac010 = v_ac47.aac010 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aae006 = v_ac47.aae006 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aae007 = v_ac47.aae007 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac042 = v_ac47.aac042 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac043 = v_ac47.aac043 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac044 = v_ac47.aac044 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aca111 = v_ac47.aca111 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac204 = v_ac47.aac204 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac060 = v_ac47.aac060 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aae138 = v_ac47.aae138 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aae550 = v_ac47.aae550 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac300 = v_ac47.aac300 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac301 = v_ac47.aac301 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
      elsif v_type = '2' then
        --关键信息校验      
        if i_ac47.aac998 = v_ac47.aac998 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac002 = v_ac47.aac002 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac003 = v_ac47.aac003 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
      elsif v_type = '3' then
        --关键信息与上传信息校验      
        if i_ac47.aac998 is not null and i_ac47.aac998 = v_ac47.aac998 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac002 is not null and i_ac47.aac002 = v_ac47.aac002 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac058 is not null and i_ac47.aac058 = v_ac47.aac058 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac147 is not null and i_ac47.aac147 = v_ac47.aac147 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aab099 is not null and i_ac47.aab099 = v_ac47.aab099 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac003 is not null and i_ac47.aac003 = v_ac47.aac003 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac004 is not null and i_ac47.aac004 = v_ac47.aac004 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac005 is not null and i_ac47.aac005 = v_ac47.aac005 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac006 is not null and i_ac47.aac006 = v_ac47.aac006 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac161 is not null and i_ac47.aac161 = v_ac47.aac161 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac067 is not null and i_ac47.aac067 = v_ac47.aac067 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aae005 is not null and i_ac47.aae005 = v_ac47.aae005 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aae005 is not null and i_ac47.aae005 = v_ac47.aae005 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac010 is not null and i_ac47.aac010 = v_ac47.aac010 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aae006 is not null and i_ac47.aae006 = v_ac47.aae006 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aae007 is not null and i_ac47.aae007 = v_ac47.aae007 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac042 is not null and i_ac47.aac042 = v_ac47.aac042 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac043 is not null and i_ac47.aac043 = v_ac47.aac043 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac044 is not null and i_ac47.aac044 = v_ac47.aac044 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aca111 is not null and i_ac47.aca111 = v_ac47.aca111 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac204 is not null and i_ac47.aac204 = v_ac47.aac204 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac060 is not null and i_ac47.aac060 = v_ac47.aac060 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aae138 is not null and i_ac47.aae138 = v_ac47.aae138 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aae550 is not null and i_ac47.aae550 = v_ac47.aae550 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac300 is not null and i_ac47.aac300 = v_ac47.aac300 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
        if i_ac47.aac301 is not null and i_ac47.aac301 = v_ac47.aac301 then
          RETMSG := RETMSG || '1|';
        else
          RETMSG := RETMSG || '0|';
        end if;
      
      end if;
    end if;
  
    if v_aac997 = n_aac997 then
      RETMSG := RETMSG || '1|';
    else
      RETMSG := RETMSG || '0|';
    end if;
  
    if V_COUNT > 0 then
      RETCODE := V_COUNT;
    end if;
  
  EXCEPTION
    WHEN OTHERS THEN
      RETCODE := -1;
      RETMSG  := sqlerrm || '人员唯一性验证错误！';
  END ifEqual;

END PKG_Check_Person;
/
