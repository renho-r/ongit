CREATE package 注销 is

  -- Author  : ANGUS
  -- Created : 2014/6/30 星期一 10:29:29
  -- Purpose : 
  
PROCEDURE zhuXiao(prm_aac998 IN VARCHAR2,
                  prm_aac002 IN VARCHAR2,
                  prm_aac003 IN VARCHAR2,
                  prm_aaz401 IN VARCHAR2,   --省库系统节点ID
                  prm_aaz400 IN VARCHAR2,   --业务系统节点ID
                  prm_aae547 IN VARCHAR2,   --注销原因
                  prm_aaz357 IN VARCHAR2,   --业务发起流水号
                  prm_appcode OUT VARCHAR2,
                  prm_errormsg OUT VARCHAR2);

end 注销;
/
