CREATE PACKAGE PKG_UPDATECARD IS

  /*
         卡变更
         20140623
         fht
  */

  PROCEDURE updatecard(v_az21     in az21%rowtype,
                       pi_aaz375  in varchar2,
                       pi_aaz400  in varchar2,
                       v_out_az21 out az21%rowtype,
                       v_out_az20 out az20%rowtype,
                       msg        out varchar2,
                       flag       out varchar2);

  /*
           卡新增测试
  */
  PROCEDURE test_addcard(bjbh in varchar2,
                         sbkh in varchar2,
                         msg  out varchar2);
  /*
           卡更新测试
  */
  PROCEDURE test_updatecard(pi_aaz007 in number, msg out varchar2);
end PKG_UPDATECARD;
/
