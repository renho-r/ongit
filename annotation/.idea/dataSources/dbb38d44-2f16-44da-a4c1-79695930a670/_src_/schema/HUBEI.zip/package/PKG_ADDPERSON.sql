CREATE PACKAGE pkg_addPerson IS

  PROCEDURE addPersonForProvince(v_ac47   IN ac47%rowtype,
                                 v_AAZ401 in VARCHAR2,
                                 v_AAZ400 in VARCHAR2,
                                 RETCODE  OUT NUMBER,
                                 RETMSG   OUT VARCHAR2);

  PROCEDURE addPersonInterfaceForProvince(v_ac47   IN ac47%rowtype,
                                          v_AAZ401 in VARCHAR2,
                                          v_AAZ400 in VARCHAR2,
                                          v_AAZ372 in number,
                                          RETCODE  OUT NUMBER,
                                          RETMSG   OUT VARCHAR2);

end pkg_addPerson;
/
