CREATE PACKAGE BODY PKG_PERSONMINORMODIFY IS

   /*--------------------------------------------------------------------------
  || 过程名称 ：PRC_K_人员次关键信息变更
  || 功能描述 ：          
  ||
  || 作    者 ：dufei 完成日期 ：20140623
  ||--------------------------------------------------------------------------*/
  PROCEDURE PERSONMINORMODIFY(PRM_部级人员ID        in VARCHAR2,
                              PRM_社会保障号码      in VARCHAR2,
                              PRM_人员信息版本号    in VARCHAR2,
                              PRM_变更信息项1        in VARCHAR2,
                              PRM_变更前信息1        in VARCHAR2,
                              PRM_变更后信息1        in VARCHAR2,
                              PRM_变更信息项2        in VARCHAR2,
                              PRM_变更前信息2        in VARCHAR2,
                              PRM_变更后信息2        in VARCHAR2,
                              PRM_发起地业务流水号  in VARCHAR2,
                              PRM_业务发起节点ID    in VARCHAR2,
                              PRM_省行政区划        in VARCHAR2,
                              PRM_APPCODE           OUT NUMBER,
                              PRM_ERRMSG            OUT VARCHAR2) IS
                      
  N_COUNT    NUMBER := 0; 
  N_AAC998   NUMBER(20);
  N_AAC997   VARCHAR(20);
  N_AAZ002   NUMBER(16);
  N_AAZ401   VARCHAR(20);
  v_aae514  VARCHAR2(4000);  
  N_变更项中文含义1  VARCHAR(20);
  N_变更项中文含义2  VARCHAR(20);
  
 BEGIN
        --查询社保号锁定表
         SELECT COUNT(1)
           INTO N_COUNT
           FROM AZ15
          WHERE　AAC002 = PRM_社会保障号码;
        --查询部级人员ID,人员信息版本号   
        SELECT AAC998,AAC997 
　　　　  INTO N_AAC998,N_AAC997 
　　　　  FROM AZ10 
　　 　  WHERE AAC998 = PRM_部级人员ID;
        

    --次关键信息变更项校验（次关键信息变更信息项只能是生存状态，死亡日期）
     IF  PRM_变更信息项1 = 'AAC060' OR PRM_变更信息项2 = 'AAE138' THEN
       
          IF N_COUNT > 0 then  --判断变更人员时候处于社会保障号锁定期    
            PRM_ERRMSG := '变更人员处于社会保障号锁定期，不可进行信息修改操作！';
          END IF;

        IF N_AAC998  IS  NOT NULL  THEN
          
            IF N_AAC997 <> PRM_人员信息版本号 then
               PRM_ERRMSG := '变更人员次关键人员信息版本号不一致，需要与部库人员信息版本号一致，调用人员统一验证！';
            ELSE  
              
               UPDATE AZ10  SET AAC997 = N_AAC997 WHERE AAC998 = PRM_部级人员ID;  
              
              IF  PRM_变更信息项1 = 'AAC060' THEN   
                  UPDATE AC47 SET AAC060 = PRM_变更后信息1 WHERE AAC998 = PRM_部级人员ID;
              END IF;
              IF  PRM_变更信息项2 = 'AAE138' THEN   
                  UPDATE AC47 SET AAE138 = PRM_变更后信息2 WHERE AAC998 = PRM_部级人员ID;
              END IF;
              
            END IF;
            
           IF  PRM_变更信息项1 = 'AAC060' THEN 
               N_变更项中文含义1 :='生存状态';
           END IF;   
 
            INSERT INTO AZ12    --插入 人员基础信息变更明细表
                    ( aaz205,   --变更记录ID
                      aaz002,   --业务日志ID
                      aac998,   --部级人员ID
                      aae122,   --变更项目
                      aae155,   --变更项中文含义
                      aae123,   --变更前值
                      aae124,   --变更后值
                      aae035 )   --变更日期
                     VALUES
                     (SEQ_AAZ205.nextval,
                      SEQ_AAZ002.nextval,
                      PRM_部级人员ID,
                      PRM_变更信息项1,
                      N_变更项中文含义1,
                      PRM_变更前信息1,
                      PRM_变更后信息1,
                        SYSDATE);
                        
           IF  PRM_变更信息项2 = 'AAE138' THEN 
               N_变更项中文含义2 :='死亡日期';
           END IF; 
                  
           INSERT INTO AZ12    --插入 人员基础信息变更明细表
                    ( aaz205,   --变更记录ID
                      aaz002,   --业务日志ID
                      aac998,   --部级人员ID
                      aae122,   --变更项目
                      aae155,   --变更项中文含义
                      aae123,   --变更前值
                      aae124,   --变更后值
                      aae035 )   --变更日期
                     VALUES
                     (SEQ_AAZ205.nextval,
                      SEQ_AAZ002.nextval,
                      PRM_部级人员ID,
                      PRM_变更信息项2,
                      N_变更项中文含义2,
                      PRM_变更前信息2,
                      PRM_变更后信息2,
                        SYSDATE);     
                 
           ELSE             
             PRM_ERRMSG := '部库没有要变更的该人员信息，不能发起次关键信息变更业务';  
           END IF;
 
          select AAZ002 into N_AAZ002 FROM  AZ12 where AAC998 = PRM_部级人员ID and AAE124= PRM_变更后信息1 ;
        
           INSERT INTO az30 --插入业务日志表
                    (aaz002,               --业务日志ID
                     aaz375,               --发起地业务流水号
                     aaz400,               --业务发起节点ID
                     aaz007,               --社保卡信息ID
                     aac998,               --部级人员ID
                     aaa235,               --业务类型编码
                     aae036,               --业务处理日期
                     aad127,               --附件张数
                     aaf018,               --省行政区划
                     aaf017,               --市行政区划
                     aae013,               --备注
                     aae512)               --本地处理结果
                  VALUES
                    (N_AAZ002,    
                     PRM_发起地业务流水号,  
                     PRM_业务发起节点ID,   
                     NULL,                  
                     PRM_部级人员ID,        
                     '002',                
                     SYSDATE,               
                     '1',                   
                     PRM_省行政区划,        
                     NULL,                  
                     NULL,                  
                     '1');    
     ELSE                              
       PRM_ERRMSG  := '次关键信息变更信息项不正确，请检查!';
     END IF; 
     
          SELECT AAZ401 INTO N_AAZ401 FROM AZ11 WHERE AAC998 = PRM_部级人员ID;
           
         v_aae514 := PRM_部级人员ID||'|'||PRM_社会保障号码||'|'||PRM_人员信息版本号||'|'||PRM_变更信息项1||'|'||PRM_变更前信息1||'|'||PRM_变更后信息1; 
          
          INSERT INTO bjckk.az42 --插入 推送队列
                    (aaz372,--推送队列ID
                     aaz002,--业务日志ID
                     aac998,--部级人员ID
                     aae532,--进队列日期
                     aae514,--发出请求报文               
                     aaz401,--关联省库系统节点ID
                     aaz400,--关联业务系统节点ID               
                     aae539,--推送失败次数              
                     aaa235)--业务类型编码               
                  VALUES
                    (bjckk.SEQ_AAZ372.nextval,    
                     N_AAZ002,  
                     PRM_部级人员ID,   
                     SYSDATE,  
                     v_aae514,
                     N_AAZ401,       
                     PRM_业务发起节点ID,                          
                     '0',
                     '002');    
          
      
--部分校验（人员信息版本号验证）   
          EXCEPTION
            WHEN OTHERS THEN
              PRM_APPCODE := -1;
              PRM_ERRMSG  := 'PKG_人员次关键信息变更失败!' ||SQLERRM;
          RETURN;
  END PERSONMINORMODIFY;

END PKG_PERSONMINORMODIFY;
/
