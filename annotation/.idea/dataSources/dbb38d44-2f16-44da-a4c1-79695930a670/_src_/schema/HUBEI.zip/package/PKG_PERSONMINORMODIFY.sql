CREATE package PKG_PERSONMINORMODIFY is

  /*--------------------------------------------------------------------------
  || 过程名称 ：PRC_K_人员次关键信息变更
  || 功能描述 ：          
  ||
  || 作    者 ：dufei 完成日期 ：20140623
  ||--------------------------------------------------------------------------*/

  PROCEDURE PERSONMINORMODIFY(PRM_部级人员ID        in VARCHAR2,
                              PRM_社会保障号码      in VARCHAR2,
                              PRM_人员信息版本号    in VARCHAR2,
                              PRM_变更信息项1        in VARCHAR2,
                              PRM_变更前信息1        in VARCHAR2,
                              PRM_变更后信息1        in VARCHAR2,
                              PRM_变更信息项2        in VARCHAR2,
                              PRM_变更前信息2        in VARCHAR2,
                              PRM_变更后信息2        in VARCHAR2,
                              PRM_发起地业务流水号  in VARCHAR2,
                              PRM_业务发起节点ID    in VARCHAR2,
                              PRM_省行政区划        in VARCHAR2,
                              PRM_APPCODE           OUT NUMBER,
                              PRM_ERRMSG            OUT VARCHAR2);                       
                                           

end PKG_PERSONMINORMODIFY;
/
