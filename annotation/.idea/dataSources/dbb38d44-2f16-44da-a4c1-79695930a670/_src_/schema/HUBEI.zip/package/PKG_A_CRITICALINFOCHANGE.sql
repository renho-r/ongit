CREATE package PKG_A_CRITICALINFOCHANGE is

  /*--------------------------------------------------------------------------
  || 过程名称 ：PKG_A_CRITICALINFOCHANGE
  || 功能描述 ：
  ||            
  ||
  || 作    者 ：sunab  完成日期 ：20140624
  ||--------------------------------------------------------------------------
  || 修改记录 ： 
  ||-------------------------------------------------------------------------*/
   PROCEDURE PKG_A_CRITICALINFOCHANGE(PRM_AAC998 IN NUMBER,--部级人员ID
                                      PRM_AAC002 IN VARCHAR2,--社会保障号码
                                      PRM_AAC997 IN VARCHAR2,--人员信息版本号
                                      PRM_AAZ400 IN VARCHAR2,--业务发起节点
                                      PRM_AAE122 IN VARCHAR2,--变更信息项
                                      PRM_AAE123 IN VARCHAR2,--变更前信息
                                      PRM_AAE124 IN VARCHAR2,--变更后信息
                                      PRM_APPCODE  OUT NUMBER,
                                      PRM_ERRMSG   OUT VARCHAR2);

end PKG_A_CRITICALINFOCHANGE;
/
