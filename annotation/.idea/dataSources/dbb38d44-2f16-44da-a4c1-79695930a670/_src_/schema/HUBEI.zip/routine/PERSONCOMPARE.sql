CREATE procedure PersonCompare is
begin
  insert into az66
    (AAB301, -- VARCHAR2(6)  Y                         
     AAE043, -- VARCHAR2(6)  Y                         
     AAC001, -- VARCHAR2(20) Y                         
     AAC003, -- VARCHAR2(50) Y                         
     AAC002, -- VARCHAR2(18) Y                         
     AAE138, -- VARCHAR2(8)  Y                         
     AAE140, -- VARCHAR2(3)  Y                         
     AAE013, -- VARCHAR2(3)  Y                         
     AAE111, -- VARCHAR2(50) Y                         
     AAE112)
    select AAB301, -- VARCHAR2(6)  Y                         
           AAE043, -- VARCHAR2(6)  Y                         
           AAC001, -- VARCHAR2(20) Y                         
           AAC003, -- VARCHAR2(50) Y                         
           AAC002, -- VARCHAR2(18) Y                         
           AAE138, -- VARCHAR2(8)  Y                         
           AAE140, -- VARCHAR2(3)  Y                         
           AAE013, -- VARCHAR2(3)  Y                         
           AAE111, -- VARCHAR2(50) Y                         
           0
      from sitrbpbd1.iy04 a
     where not exists (select 1 from az66 b where a.aac001 = b.aac001);
end;
/
