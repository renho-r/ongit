CREATE PROCEDURE CHECK_IDCARD_VALIDATE(V_AAC147 in varchar2,
                                                  Result   OUT varchar2) is
  /*    v_aac002 varchar2(20);
  BEGIN*/

  --判断身份证是否合法，思路如下：15位不作处理，18为先处理成15位（15位没有验证位）再转成18位与输入的身份证号比较
  --问题：函数SF_00_TO_ID18无处理2000年以后的，需要自己修改
  /*    if (length(v_aac147) = 15) then
    Result := '1';
  else
    v_aac002 := substr(v_aac147, 1, 6) || substr(v_aac147, 9, 9); --18为先处理成15位


    v_aac002 := SF_00_TO_ID18(v_aac002); --转成18位*/

  type TIArray is table of integer;
  type TCArray is table of char(1);
  v_aac002 varchar2(20);
  W        TIArray;
  A        TCArray;
  S        integer;
BEGIN
  W        := TIArray(7,
                      9,
                      10,
                      5,
                      8,
                      4,
                      2,
                      1,
                      6,
                      3,
                      7,
                      9,
                      10,
                      5,
                      8,
                      4,
                      2,
                      1);
  A        := TCArray('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
  v_aac002 := SubStr(V_AAC147, 1, 17);

  S := 0;
  begin
    for i in 1 .. 17 loop
      S := S + to_number(SubStr(v_aac002, i, 1)) * W(i);
    end loop;
  exception
    when others then
      Result := '';
  end;
  S := S mod 11;

  v_aac002 := v_aac002 || A(s + 1);

  Result := v_aac002;

END CHECK_IDCARD_VALIDATE;
/
