CREATE PROCEDURE pcd_lxyw(   --轮询业务
    lxpch    IN number,--轮询批次号,由业务系统上传
    cxlx     IN VARCHAR2,--查询类型：1是查上传批次；2是将上传批次打成已读标志，并取下一个批次发送
    xtjdid   IN VARCHAR2,--系统节点ID
    fqdywlsh IN VARCHAR2,--发起地业务流水号
    res OUT VARCHAR2)    --返回信息
IS
 
  ret_c1 az51%rowtype;
  ret_c2 az51%rowtype;
  ret_c3 az51%rowtype;
  ret_c4 az51%rowtype;
  aae522_temp VARCHAR2(1000); --修改内容结构串
  aaa235_temp VARCHAR2(3);    --业务类型编码
  aae529_temp VARCHAR2(500);  --信息摘要
  aae507_temp NUMBER(16);     --下一批次号
  aaz002_temp NUMBER(16);     --业务日志ID
  aae514_temp VARCHAR2(1000); --轮询向部库请求报文
  v_count     NUMBER(2);
  aae505_temp NUMBER(16); --新产生轮询批次号
  error_lxpch EXCEPTION;
  
   CURSOR c1
  IS
    SELECT * FROM az51 WHERE aae505=lxpch;
  CURSOR c2
  IS
    SELECT * FROM az51 WHERE aae505=aae507_temp;
  CURSOR c3
  IS
    SELECT *
    FROM
      (SELECT * FROM az51 WHERE aaz400=xtjdid AND aae505 IS NULL ORDER BY aaz369
      )
  WHERE rownum<=100;
  CURSOR c4
  IS
    SELECT * FROM az51 WHERE aae505=aae505_temp;
BEGIN
  res        :='';
  aaz002_temp := seq_aaz002.nextval;
  IF cxlx     = '1' THEN --查询当前批次号的数据
    IF lxpch IS NULL THEN --判断批次号是否为空
      raise error_lxpch;
    END IF;
    OPEN c1;
    LOOP
      FETCH c1 INTO ret_c1;
      EXIT
    WHEN c1%notfound;
      BEGIN
        res := res||lxpch||ret_c1.aae522||ret_c1.aaa235||ret_c1.aae529||'\r\n';
      END;
    END LOOP;
    CLOSE c1;
  ELSE
    SELECT NVL(MAX(aae507),0) INTO aae507_temp FROM az52;
    IF lxpch <aae507_temp THEN
      SELECT aae507 INTO aae507_temp FROM az52 WHERE aae506=lxpch;
      OPEN c2;
      LOOP
        FETCH c2 INTO ret_c2;
        EXIT
      WHEN c2%notfound;
        BEGIN
          res := res||lxpch||ret_c2.aae522||ret_c2.aaa235||ret_c2.aae529||'\r\n';
        END;
      END LOOP;
      CLOSE c2;
      UPDATE az51 SET aae556=sysdate WHERE aaz400 = xtjdid AND aae505=aae507_temp;
    elsif lxpch = aae507_temp THEN
      SELECT COUNT(1)
      INTO v_count
      FROM az51
      WHERE aaz400   = xtjdid
      AND aae505    IS NULL;
      IF v_count     > 0 THEN
        aae505_temp := seq_aae505.nextval;
        OPEN c3;
        LOOP
          FETCH c3 INTO ret_c3;
          EXIT
        WHEN c3%notfound;
          BEGIN
            res := res||lxpch||ret_c3.aae522||ret_c3.aaa235||ret_c3.aae529||'\r\n';
            UPDATE az51 SET aae505 = aae505_temp WHERE aaz369 = ret_c3.aaz369;
            UPDATE az51 SET aae556=sysdate WHERE aaz400 = xtjdid AND aaz369=ret_c3.aaz369;
          END;
        END LOOP;
        CLOSE c3;
      ELSE
        res := '';
      END IF;
      UPDATE az51 SET asr031='1',asr032=sysdate WHERE aae505=lxpch;
      insert into az52 values (xtjdid,lxpch,aae505_temp);
    ELSE
      res := '';
    END IF;
    OPEN c4;
    LOOP
      FETCH c4 INTO ret_c4;
      EXIT
    WHEN c4%notfound;
      BEGIN
        aae514_temp :=aae514_temp||chr(13)||lxpch||ret_c4.aaz372||ret_c4.aaa235||'\r\n';
        INSERT
        INTO az24 VALUES
          (
            seq_aaz365.nextval,
            aae514_temp,
            ret_c4.aaa235,
            sysdate,
            ret_c4.aaz369,
            ret_c4.aaz372,
            0
          );
      END;
    END LOOP;
  END IF;
  INSERT
  INTO az30 VALUES
    (
      aaz002_temp,
      fqdywlsh,
      xtjdid,
      NULL,
      NULL,
      '011',
      sysdate,
      0,
      SUBSTR(xtjdid,0,2),
      SUBSTR(xtjdid,0,4),
      '轮询',
      NULL,
      '1',
      '1',
      '0'
    );
  res :='OK';
EXCEPTION
WHEN error_lxpch THEN
  Dbms_output.put_line('轮询批次号不能为空！');
WHEN no_data_found THEN
  Dbms_Output.put_line('no_data_found');
WHEN TOO_MANY_ROWS THEN
  Dbms_Output.put_line('TOO_MANY_ROWS');
WHEN OTHERS THEN
  raise_application_error(SQLCODE,sqlerrm,false);
END;
/
