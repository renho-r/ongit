CREATE procedure Az31ToAz70 is
begin
  
end ;
/
