CREATE PROCEDURE pcd_kwlx( --勘误推送到省进轮询表
    kwts IN KWTSINFO,
    res OUT VARCHAR2) --返回信息
IS
  aaz002_temp NUMBER(16);
  v_count     NUMBER(2);
  error       EXCEPTION;
BEGIN
  aaz002_temp   := seq_aaz002.nextval;
  IF kwts.hskwjg ='10' OR kwts.hskwjg ='00' THEN
    DELETE az11 WHERE aac998=kwts.bjryid AND aaz400=kwts.xtjdid;
    SELECT COUNT(1) INTO v_count FROM az11 WHERE aac998=kwts.bjryid;
    IF v_count=0 THEN
      INSERT INTO az13
      SELECT * FROM ac47 WHERE aac998=kwts.bjryid;
      DELETE ac47 WHERE aac998=kwts.bjryid;--删除人员信息表记录
      DELETE az10 WHERE aac998=kwts.bjryid;--删除人员识别表记录
    END IF;
  END IF;
  INSERT
  INTO az51 VALUES
    (
      seq_aaz369.nextval,
      aaz002_temp,
      kwts.tsdlid,
      kwts.lxlx00,
      kwts.xtjdid,
      kwts.bjryid,
      kwts.shbzhm,
      kwts.fqfxm0,
      kwts.hskwlsh,
      kwts.hskwfqrq,
      kwts.hskwfqjd,
      '0',
      NULL,
      NULL,
      NULL,
      kwts.hskwjg,
      kwts.xxzy,
      kwts.xgnrjgc,
      NULL,
      kwts.ywlxbm,
      NULL
    );
  INSERT
  INTO az30 VALUES
    (
      aaz002_temp,
      kwts.fqdywlsh,
      kwts.hskwfqjd,
      NULL,
      kwts.bjryid,
      kwts.ywlxbm,
      sysdate,
      0,
      SUBSTR(kwts.xtjdid,0,2),
      SUBSTR(kwts.xtjdid,0,4),
      '勘误日志',
      NULL,
      '1',
      '1',
      '0'
    );
EXCEPTION
WHEN no_data_found THEN
  Dbms_Output.put_line('no_data_found');
WHEN TOO_MANY_ROWS THEN
  Dbms_Output.put_line('TOO_MANY_ROWS');
WHEN OTHERS THEN
  raise_application_error(SQLCODE,sqlerrm,false);
END;
/
