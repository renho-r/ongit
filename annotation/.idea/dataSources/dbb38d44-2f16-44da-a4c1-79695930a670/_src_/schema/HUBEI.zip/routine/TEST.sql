CREATE procedure test(名称 in out 类型, 名称 in out 类型, ...) is
begin
  
end test;
/
