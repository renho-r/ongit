CREATE function func_getSeparateValue(strSource IN VARCHAR2,
                                                 strTag    IN VARCHAR2,
                                                 nIndex    IN NUMBER ) return varchar2 is
  Result varchar2(200);
  N_pos0 NUMBER;
  N_pos1 NUMBER;
  N_pos2 NUMBER;
  N_pos3 NUMBER;
  strSrc varchar2(2000);

BEGIN
  
  SELECT INSTR(strSource,strTag, 1, 1) INTO N_pos0 FROM dual;
  if nvl(N_pos0, 0) = 0 THEN
     RETURN '';
  END IF;
  
  SELECT substr(strSource, N_pos0 + length(strTag)) INTO strSrc FROM dual;
  
  SELECT INSTR(strSrc, '<', 1, 1) INTO N_pos3 FROM dual;
  if nvl(N_pos3, 0) = 0 THEN
     RETURN '';
  END IF;
  
  SELECT substr(strSrc, 1, N_pos3 - 1) INTO strSrc FROM dual;

  strSrc := '|' || strSrc || '|';
  
  SELECT INSTR(strSrc, '|', 1, nIndex)   INTO N_pos1 FROM DUAL;
  SELECT INSTR(strSrc, '|', 1, nIndex+1) INTO N_pos2 FROM DUAL;
  
  select substr(strSrc, N_pos1+1, N_pos2 - N_pos1 - 1) into Result from dual;
  
  Result := replace(Result, CHR(10), '');
  
  RETURN Result;
  
end func_getSeparateValue;
/
