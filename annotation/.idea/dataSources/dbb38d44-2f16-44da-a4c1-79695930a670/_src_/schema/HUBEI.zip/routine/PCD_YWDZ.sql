CREATE PROCEDURE pcd_ywdz( --业务对账
    temp IN VARCHAR2,
    res_sk OUT VARCHAR2) --返回信息
IS
  CURSOR c1
  IS
    SELECT *
    FROM az30
    WHERE aae511='1'
    AND aaa235 IN ('001','002','003') --人员业务
    AND aae518  ='2'
    AND aae036 >=sysdate-7;
  ret_c1 c1%rowtype;
  res     VARCHAR2(1);
  v_jylsh NUMBER(18);
  v_count NUMBER(2);
BEGIN
  OPEN c1;
  LOOP
    FETCH c1 INTO ret_c1;
    EXIT
  WHEN c1%notfound;
    BEGIN
      bjckk.pcd_ywdzcl(ret_c1.aaz375,ret_c1.aaz400,ret_c1.aaa235,res);
      IF res ='1' THEN
        SELECT aaz374
        INTO v_jylsh
        FROM az32
        WHERE aaz375     =ret_c1.aaz375
        AND aaz400       = ret_c1.aaz400;
        IF ret_c1.aaa235 = '001' THEN
          v_count       :=1;
          --调用人员新增（v_jylsh);
        elsif ret_c1.aaa235 = '002' THEN
          v_count          :=1;
          --调用人员变更（v_jylsh);
        ELSE
          v_count :=1;
          --调用人员注销（v_jylsh);
        END IF;
      END IF;
      UPDATE az30 SET aae531='1' WHERE aaz002 = ret_c1.aaz002;
    END;
  END LOOP;
EXCEPTION
WHEN no_data_found THEN
  Dbms_Output.put_line('no_data_found');
WHEN TOO_MANY_ROWS THEN
  Dbms_Output.put_line('TOO_MANY_ROWS');
WHEN OTHERS THEN
  raise_application_error(SQLCODE,sqlerrm,false);
END;
/
