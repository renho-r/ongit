CREATE VIEW HSBP_DIC_DATA AS select aaz093 as id, aaa100 as code, aaa102 as value, aaa103 as text, '' as pinyin, '' as filter, '1' as status, '0' as priority  from aa10
/
