CREATE VIEW DIC_TYPE AS select aaa100 as code, aaa101 as name from aa10 group by aaa100, aaa101
/
